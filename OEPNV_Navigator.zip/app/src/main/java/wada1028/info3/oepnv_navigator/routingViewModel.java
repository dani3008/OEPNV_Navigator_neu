package wada1028.info3.oepnv_navigator;

import androidx.lifecycle.ViewModel;

public class routingViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
